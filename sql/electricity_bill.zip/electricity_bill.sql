-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2017-05-02 04:47:10
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `electricity_bill`
--

-- --------------------------------------------------------

--
-- 表的结构 `north_building`
--

CREATE TABLE `north_building` (
  `north_building_id` int(11) NOT NULL,
  `building_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `qiaoyuan_room_bill`
--

CREATE TABLE `qiaoyuan_room_bill` (
  `room_id` int(11) NOT NULL,
  `north_building_id` int(11) NOT NULL,
  `room_name` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL DEFAULT '2',
  `remain` double NOT NULL,
  `total_use` double NOT NULL,
  `total_buy` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `southwest_room_bill`
--

CREATE TABLE `southwest_room_bill` (
  `room_id` int(11) NOT NULL,
  `north_building_id` int(11) NOT NULL,
  `room_name` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL DEFAULT '2',
  `remain` double NOT NULL,
  `total_use` double NOT NULL,
  `total_buy` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `south_building`
--

CREATE TABLE `south_building` (
  `south_building_id` int(11) NOT NULL,
  `building_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `south_room_bill`
--

CREATE TABLE `south_room_bill` (
  `room_id` int(11) NOT NULL,
  `south_building_id` int(11) NOT NULL,
  `room_name` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL DEFAULT '2',
  `remain` double NOT NULL,
  `total_use` double NOT NULL,
  `total_buy` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `xili_building`
--

CREATE TABLE `xili_building` (
  `xili_building_id` int(11) NOT NULL,
  `building_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `status` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `xili_room_bill`
--

CREATE TABLE `xili_room_bill` (
  `room_id` int(11) NOT NULL,
  `xili_building_id` int(11) NOT NULL,
  `room_name` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL DEFAULT '2',
  `remain` double NOT NULL,
  `total_use` double NOT NULL,
  `total_buy` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `zhaiqu_room_bill`
--

CREATE TABLE `zhaiqu_room_bill` (
  `room_id` int(11) NOT NULL,
  `north_building_id` int(11) NOT NULL,
  `room_name` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL DEFAULT '2',
  `remain` double NOT NULL,
  `total_use` double NOT NULL,
  `total_buy` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `north_building`
--
ALTER TABLE `north_building`
  ADD PRIMARY KEY (`north_building_id`);

--
-- Indexes for table `south_building`
--
ALTER TABLE `south_building`	
  ADD PRIMARY KEY (`south_building_id`);

--
-- Indexes for table `xili_building`
--
ALTER TABLE `xili_building`
  ADD PRIMARY KEY (`xili_building_id`);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
